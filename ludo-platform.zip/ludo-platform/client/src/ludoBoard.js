export const COLORS = ["RED","YELLOW","GREEN","BLUE"];
export const COLOR_INDEX = { RED:0, YELLOW:1, GREEN:2, BLUE:3 };

export function buildLoopCoords(cx, cy, r) {
  const coords = [];
  for (let i = 0; i < 52; i++) {
    const a = (Math.PI * 2 * i) / 52 - Math.PI / 2;
    coords.push({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r });
  }
  return coords;
}

function homeBase(color){ return 1000 + COLOR_INDEX[color]*10; }

export function tokenCoord(pos, loopCoords, baseAnchors, color) {
  if (pos === -1) return baseAnchors[color];
  if (pos >= 0 && pos <= 51) return loopCoords[pos];

  if (pos >= 1000 && pos <= 1039) {
    const step = pos - homeBase(color);
    const c = { x: 240, y: 250 };
    const d = 18 * (step + 1);
    if (color === "RED") return { x: c.x - d, y: c.y };
    if (color === "GREEN") return { x: c.x + d, y: c.y };
    if (color === "YELLOW") return { x: c.x, y: c.y - d };
    if (color === "BLUE") return { x: c.x, y: c.y + d };
  }
  return { x: 240, y: 250 };
}

export function colorFill(color){
  if(color==="RED") return "#ff4d4d";
  if(color==="GREEN") return "#36d46a";
  if(color==="YELLOW") return "#ffd24a";
  return "#4aa3ff";
}
