import React, { useEffect, useMemo, useState } from "react";
import { io } from "socket.io-client";
import { api, apiUrl, setToken, clearToken, getToken } from "./api";
import { buildLoopCoords, tokenCoord, colorFill, COLORS } from "./ludoBoard";

export default function App(){
  const [tab, setTab] = useState("play"); // play | wallet | admin | login
  const [me, setMe] = useState(null);
  const [error, setError] = useState("");

  async function refreshMe(){
    try{
      if(!getToken()){ setMe(null); return; }
      const r = await api.me();
      setMe(r.user);
    }catch{
      clearToken();
      setMe(null);
    }
  }

  useEffect(()=>{ refreshMe(); }, []);

  const isAdmin = me?.role === "admin";

  return (
    <div style={{ maxWidth: 1100, margin: "0 auto", padding: 16 }}>
      <div style={{display:"flex", gap:10, alignItems:"center", flexWrap:"wrap"}}>
        <div style={{fontWeight:950, fontSize:20}}>Ludo Platform</div>
        <div style={{opacity:0.75, fontSize:12}}>API: {apiUrl()}</div>
        <div style={{flex:1}} />

        <button style={tabBtn(tab==="play")} onClick={()=>setTab("play")}>Play</button>
        <button style={tabBtn(tab==="wallet")} onClick={()=>setTab("wallet")}>Wallet</button>
        {isAdmin ? <button style={tabBtn(tab==="admin")} onClick={()=>setTab("admin")}>Admin</button> : null}

        {me ? (
          <div style={{display:"flex", gap:10, alignItems:"center"}}>
            <div style={{opacity:0.9}}>
              <b>{me.display_name}</b> • Balance: <b>{me.balance}</b>
            </div>
            <button style={btnGhost} onClick={()=>{ clearToken(); setMe(null); setTab("login"); }}>Logout</button>
          </div>
        ) : (
          <button style={btn} onClick={()=>setTab("login")}>Login</button>
        )}
      </div>

      {error ? <div style={{marginTop:10, color:"#ffb4b4"}}>{error}</div> : null}

      {tab==="login" ? <Auth onAuthed={(u)=>{ setMe(u); setTab("play"); }} setError={setError} /> : null}
      {tab==="wallet" ? <Wallet me={me} setMe={setMe} setError={setError} /> : null}
      {tab==="admin" ? <Admin me={me} setError={setError} /> : null}
      {tab==="play" ? <Play me={me} setError={setError} /> : null}
    </div>
  );
}

function Auth({onAuthed, setError}){
  const [mode, setMode] = useState("login");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [displayName,setDisplayName]=useState("");

  async function submit(){
    setError("");
    try{
      const r = mode==="login"
        ? await api.login({email,password})
        : await api.register({email,password, displayName});
      setToken(r.token);
      onAuthed(r.user);
    }catch(e){ setError(e.message); }
  }

  return (
    <div style={{...card, marginTop:14, maxWidth:520}}>
      <div style={{display:"flex", gap:8}}>
        <button style={mode==="login"?btn:btnGhost} onClick={()=>setMode("login")}>Login</button>
        <button style={mode==="register"?btn:btnGhost} onClick={()=>setMode("register")}>Register</button>
      </div>
      <div style={{display:"grid", gap:10, marginTop:12}}>
        {mode==="register" ? <input style={input} placeholder="Display name" value={displayName} onChange={e=>setDisplayName(e.target.value)} /> : null}
        <input style={input} placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input style={input} placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button style={btn} onClick={submit}>{mode==="login" ? "Login" : "Create account"}</button>
        <div style={{opacity:0.75, fontSize:12}}>
          Admin login is set in server .env (see server/.env.example).
        </div>
      </div>
    </div>
  );
}

function Wallet({me, setMe, setError}){
  const [methods,setMethods]=useState([]);
  const [amount,setAmount]=useState(50);
  const [methodId,setMethodId]=useState("");

  async function load(){
    setError("");
    try{
      const [m, r] = await Promise.all([api.depositMethods(), api.me()]);
      setMethods(m.rows);
      setMe(r.user);
    }catch(e){ setError(e.message); }
  }
  useEffect(()=>{ load(); }, []);

  async function deposit(){
    setError("");
    try{
      const r = await api.deposit({ amount:Number(amount), methodId: methodId?Number(methodId):null });
      setMe(r.user);
      await load();
    }catch(e){ setError(e.message); }
  }

  if(!me) return <div style={{...card, marginTop:14}}>Please login to use Wallet.</div>;

  return (
    <div style={{display:"flex", gap:14, flexWrap:"wrap", marginTop:14}}>
      <div style={{...card, minWidth:360, flex:1}}>
        <div style={{fontWeight:900}}>Deposit (adds coins instantly)</div>
        <div style={{opacity:0.75, fontSize:12, marginTop:6}}>
          This is a credit system demo (no payment gateway connected).
        </div>
        <div style={{display:"grid", gap:10, marginTop:12}}>
          <input style={input} type="number" min="1" value={amount} onChange={e=>setAmount(e.target.value)} />
          <select style={input} value={methodId} onChange={e=>setMethodId(e.target.value)}>
            <option value="">Select method</option>
            {methods.map(m=> <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
          <button style={btn} onClick={deposit}>Deposit & Add Coins</button>
        </div>
        <div style={{marginTop:12, opacity:0.9}}>Balance: <b>{me.balance}</b></div>
      </div>

      <div style={{...card, minWidth:420, flex:1}}>
        <div style={{fontWeight:900}}>Active Deposit Methods</div>
        <div style={{marginTop:10}}>
          {methods.length ? methods.map(m=> (
            <div key={m.id} style={{padding:10, border:"1px solid rgba(255,255,255,0.12)", borderRadius:12, marginBottom:8}}>
              <div style={{fontWeight:900}}>{m.name}</div>
              <div style={{opacity:0.85, fontSize:12, whiteSpace:"pre-wrap"}}>{m.details}</div>
            </div>
          )) : <div style={{opacity:0.7}}>No methods yet. Admin can add.</div>}
        </div>
      </div>
    </div>
  );
}

function Admin({me, setError}){
  const [users,setUsers]=useState([]);
  const [q,setQ]=useState("");
  const [methods,setMethods]=useState([]);
  const [name,setName]=useState("");
  const [details,setDetails]=useState("");

  const isAdmin = me?.role === "admin";

  async function load(){
    setError("");
    try{
      const [u,m] = await Promise.all([api.adminUsers(q), api.adminMethods()]);
      setUsers(u.rows);
      setMethods(m.rows);
    }catch(e){ setError(e.message); }
  }
  useEffect(()=>{ if(isAdmin) load(); }, [isAdmin]);

  async function adjust(userId, delta){
    setError("");
    try{
      await api.adminAdjust({ userId, delta, reason:"ADMIN_ADJUST" });
      await load();
    }catch(e){ setError(e.message); }
  }
  async function addMethod(){
    setError("");
    try{
      await api.adminAddMethod({ name, details, isActive: 1 });
      setName(""); setDetails("");
      await load();
    }catch(e){ setError(e.message); }
  }

  if(!me) return <div style={{...card, marginTop:14}}>Please login.</div>;
  if(!isAdmin) return <div style={{...card, marginTop:14}}>Admin only.</div>;

  return (
    <div style={{display:"flex", gap:14, flexWrap:"wrap", marginTop:14}}>
      <div style={{...card, flex:1, minWidth:520}}>
        <div style={{fontWeight:900}}>Users</div>
        <div style={{display:"flex", gap:8, marginTop:10}}>
          <input style={input} placeholder="Search email/name" value={q} onChange={e=>setQ(e.target.value)} />
          <button style={btn2} onClick={load}>Search</button>
        </div>
        <div style={{marginTop:12, maxHeight:520, overflow:"auto"}}>
          {users.map(u=> (
            <div key={u.id} style={{padding:10, border:"1px solid rgba(255,255,255,0.12)", borderRadius:12, marginBottom:10}}>
              <div style={{display:"flex", justifyContent:"space-between", gap:10, flexWrap:"wrap"}}>
                <div>
                  <div style={{fontWeight:900}}>{u.display_name} <span style={{opacity:0.7, fontWeight:700}}>({u.email})</span></div>
                  <div style={{opacity:0.8, fontSize:12}}>Balance: <b>{u.balance}</b> • Role: {u.role}</div>
                </div>
                <div style={{display:"flex", gap:8, flexWrap:"wrap"}}>
                  <button style={btnMini} onClick={()=>adjust(u.id, 50)}>+50</button>
                  <button style={btnMini} onClick={()=>adjust(u.id, 200)}>+200</button>
                  <button style={btnMiniRed} onClick={()=>adjust(u.id, -50)}>-50</button>
                </div>
              </div>
            </div>
          ))}
          {!users.length ? <div style={{opacity:0.7}}>No users.</div> : null}
        </div>
      </div>

      <div style={{...card, flex:1, minWidth:420}}>
        <div style={{fontWeight:900}}>Deposit Methods</div>
        <div style={{marginTop:10}}>
          <div style={{fontWeight:800}}>Add new</div>
          <input style={{...input, marginTop:8}} placeholder="Method name" value={name} onChange={e=>setName(e.target.value)} />
          <textarea style={{...input, marginTop:8, minHeight:90}} placeholder="Details shown to users" value={details} onChange={e=>setDetails(e.target.value)} />
          <button style={{...btn, marginTop:8}} onClick={addMethod}>Add Method</button>
        </div>
        <div style={{marginTop:14, maxHeight:360, overflow:"auto"}}>
          {methods.map(m=> (
            <div key={m.id} style={{padding:10, border:"1px solid rgba(255,255,255,0.12)", borderRadius:12, marginBottom:10}}>
              <div style={{fontWeight:900}}>{m.name} <span style={{opacity:0.7, fontWeight:700}}>{m.is_active? "• Active":"• Disabled"}</span></div>
              <div style={{opacity:0.85, fontSize:12, whiteSpace:"pre-wrap"}}>{m.details}</div>
            </div>
          ))}
          {!methods.length ? <div style={{opacity:0.7}}>No methods yet.</div> : null}
        </div>
      </div>
    </div>
  );
}

function Play({me, setError}){
  const [roomId, setRoomId] = useState("room1");
  const [color, setColor] = useState("RED");
  const [mode, setMode] = useState("BOT"); // BOT | PVP
  const [socket, setSocket] = useState(null);
  const [game, setGame] = useState(null);
  const [moves, setMoves] = useState([]);
  const [selectedToken, setSelectedToken] = useState(null);

  const loopCoords = useMemo(() => buildLoopCoords(240, 250, 150), []);
  const baseAnchors = useMemo(() => ({
    RED: { x: 120, y: 380 },
    GREEN: { x: 360, y: 380 },
    YELLOW: { x: 120, y: 120 },
    BLUE: { x: 360, y: 120 }
  }), []);

  useEffect(() => {
    const s = io(apiUrl());
    setSocket(s);

    s.on("game:state", (g) => {
      setGame({ ...g });
      setMoves([]);
      setSelectedToken(null);
    });
    s.on("game:moves", ({ moves }) => setMoves(moves || []));
    s.on("room:error", (e) => setError(e.message || "room error"));

    return () => s.disconnect();
  }, []);

  function join(){
    setError("");
    socket.emit("room:join", { roomId, color, mode, token: getToken() });
  }
  function roll(){
    socket.emit("game:roll", { roomId, color });
  }
  function requestMoves(){
    socket.emit("game:listMoves", { roomId, color });
  }
  function doMove(tokenIndex, to){
    socket.emit("game:move", { roomId, color, tokenIndex, to });
  }

  const myTurn = game?.turn === color;
  const ready = COLORS.every(c => !!game?.players?.[c]);

  useEffect(() => {
    if (!socket || !game) return;
    if (ready && myTurn && game.mustMove && game.dice) {
      requestMoves();
    }
  }, [socket, game, ready, myTurn]);

  const myMoves = useMemo(() => {
    if (selectedToken == null) return [];
    return moves.filter(m => m.tokenIndex === selectedToken);
  }, [moves, selectedToken]);

  return (
    <div style={{marginTop:14}}>
      <div style={{display:"flex", gap:12, flexWrap:"wrap"}}>
        <div style={{...card, flex:1, minWidth:360}}>
          <div style={{fontWeight:900}}>Join Game</div>
          <div style={{display:"flex", gap:8, flexWrap:"wrap", marginTop:10}}>
            <input style={input} value={roomId} onChange={e=>setRoomId(e.target.value)} placeholder="roomId" />
            <select style={input} value={mode} onChange={e=>setMode(e.target.value)}>
              <option value="BOT">Vs Computer (3 bots)</option>
              <option value="PVP">PVP (4 humans)</option>
            </select>
            <select style={input} value={color} onChange={e=>setColor(e.target.value)}>
              {COLORS.map(c=> <option key={c} value={c}>{c}</option>)}
            </select>
            <button style={btn} onClick={join}>Join</button>
          </div>
          <div style={{marginTop:10, opacity:0.9}}>
            Ready: <b>{ready ? "YES" : "NO"}</b> • Turn: <b>{game?.turn || "-"}</b> • Dice: <b>{game?.dice ?? "-"}</b>
          </div>
          <div style={{marginTop:8, display:"flex", gap:8, flexWrap:"wrap"}}>
            <button
              style={{...btn2, opacity: (!ready || !myTurn || game?.mustMove || game?.winner) ? 0.5 : 1}}
              disabled={!ready || !myTurn || game?.mustMove || game?.winner}
              onClick={roll}
            >Roll</button>
            <button
              style={{...btnGhost, opacity: (!ready || !myTurn || !game?.mustMove || !game?.dice) ? 0.5 : 1}}
              disabled={!ready || !myTurn || !game?.mustMove || !game?.dice}
              onClick={requestMoves}
            >Show Moves</button>
          </div>
          {game?.winner ? <div style={{marginTop:10, fontWeight:950, color:"#ffd77a"}}>Winner: {game.winner}</div> : null}
          {!me ? <div style={{marginTop:10, opacity:0.75, fontSize:12}}>You can play as guest. Login to use Wallet/Admin.</div> : null}
        </div>

        <div style={{...card, flex:1, minWidth:360}}>
          <div style={{fontWeight:900}}>Board</div>
          <div style={{opacity:0.75, fontSize:12, marginTop:6}}>
            Click your token → then click highlighted GO.
          </div>

          <svg width={480} height={480} style={{marginTop:10, background:"#0f0a2a", borderRadius:16}}>
            {loopCoords.map((p,i)=> <circle key={i} cx={p.x} cy={p.y} r={7} fill="rgba(255,255,255,0.15)" />)}

            {myMoves.map((m,i)=>{
              const p = tokenCoord(m.to, loopCoords, baseAnchors, color);
              return (
                <g key={i} onClick={()=>doMove(selectedToken, m.to)}>
                  <circle cx={p.x} cy={p.y} r={16} fill="rgba(255,216,106,0.35)" stroke="rgba(255,216,106,0.9)" strokeWidth="2" />
                  <text x={p.x} y={p.y+4} textAnchor="middle" fontSize="10" fill="#fff" fontWeight="900">GO</text>
                </g>
              );
            })}

            <circle cx={240} cy={250} r={36} fill="rgba(255,255,255,0.08)" />

            {COLORS.map((c)=>{
              const tokens = game?.tokens?.[c] || [-1,-1,-1,-1];
              return tokens.map((pos,idx)=>{
                const p = tokenCoord(pos, loopCoords, baseAnchors, c);
                const isMine = c===color;
                const isSel = isMine && selectedToken===idx;
                return (
                  <g key={c+idx} onClick={()=>{ if(isMine) setSelectedToken(idx); }} style={{cursor:isMine?"pointer":"default"}}>
                    <circle cx={p.x} cy={p.y} r={isSel?14:12} fill={colorFill(c)} opacity={isMine?1:0.75}
                      stroke={isSel?"#ffd86a":"rgba(0,0,0,0.35)"} strokeWidth={isSel?3:2} />
                    <text x={p.x} y={p.y+4} textAnchor="middle" fontSize="11" fill="#0b0b0b" fontWeight="900">{idx+1}</text>
                  </g>
                );
              });
            })}
          </svg>

          <div style={{marginTop:10, opacity:0.9}}>
            You: <b>{color}</b> • Selected: <b>{selectedToken==null ? "-" : selectedToken+1}</b>
          </div>
        </div>
      </div>
    </div>
  );
}

const card = { background:"var(--card)", border:"1px solid var(--cardBorder)", borderRadius:16, padding:14 };
const input = { borderRadius:12, border:"1px solid rgba(255,255,255,0.15)", background:"rgba(0,0,0,0.25)", padding:"10px 12px", outline:"none", color:"#fff" };
const btn = { background:"linear-gradient(#ffd86a,#ffb72b)", border:"none", borderRadius:12, padding:"10px 14px", fontWeight:900, color:"#2a1a00" };
const btn2 = { background:"linear-gradient(#7ae6ff,#2cc0ff)", border:"none", borderRadius:12, padding:"10px 14px", fontWeight:900, color:"#05202a" };
const btnGhost = { background:"rgba(0,0,0,0.18)", border:"1px solid rgba(255,255,255,0.18)", borderRadius:12, padding:"10px 14px", fontWeight:800, color:"#fff" };
const btnMini = { background:"rgba(255,216,106,0.22)", border:"1px solid rgba(255,216,106,0.35)", borderRadius:10, padding:"8px 10px", fontWeight:900, color:"#fff" };
const btnMiniRed = { background:"rgba(255,80,80,0.18)", border:"1px solid rgba(255,80,80,0.35)", borderRadius:10, padding:"8px 10px", fontWeight:900, color:"#fff" };
const tabBtn = (active)=>({ ...btnGhost, borderColor: active ? "rgba(255,216,106,0.65)" : "rgba(255,255,255,0.18)" });
