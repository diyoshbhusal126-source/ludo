const API = import.meta.env.VITE_API_URL || "http://localhost:4000";

export function apiUrl(){ return API; }
export function getToken(){ return localStorage.getItem("token"); }
export function setToken(t){ localStorage.setItem("token", t); }
export function clearToken(){ localStorage.removeItem("token"); }

async function req(path, opts={}){
  const headers = { "Content-Type":"application/json", ...(opts.headers||{}) };
  const t = getToken();
  if(t) headers.Authorization = `Bearer ${t}`;
  const r = await fetch(`${API}${path}`, { ...opts, headers });
  const data = await r.json().catch(()=> ({}));
  if(!r.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  register: (payload)=> req("/api/auth/register",{ method:"POST", body:JSON.stringify(payload)}),
  login: (payload)=> req("/api/auth/login",{ method:"POST", body:JSON.stringify(payload)}),
  me: ()=> req("/api/me"),
  depositMethods: ()=> req("/api/deposit-methods"),
  deposit: (payload)=> req("/api/deposit",{ method:"POST", body:JSON.stringify(payload)}),
  ledger: ()=> req("/api/wallet/ledger"),

  adminUsers: (q)=> req(`/api/admin/users${q?`?q=${encodeURIComponent(q)}`:""}`),
  adminAdjust: (payload)=> req("/api/admin/users/adjust-balance",{ method:"POST", body:JSON.stringify(payload)}),
  adminMethods: ()=> req("/api/admin/deposit-methods"),
  adminAddMethod: (payload)=> req("/api/admin/deposit-methods",{ method:"POST", body:JSON.stringify(payload)}),
};
