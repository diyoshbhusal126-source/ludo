import jwt from "jsonwebtoken";

export function signToken(user, secret){
  return jwt.sign(
    { uid: user.id, role: user.role, email: user.email, name: user.display_name },
    secret,
    { expiresIn: "7d" }
  );
}

export function authRequired(secret){
  return (req, res, next) => {
    const h = req.headers.authorization || "";
    const token = h.startsWith("Bearer ") ? h.slice(7) : null;
    if(!token) return res.status(401).json({ error: "Missing token" });
    try{
      req.user = jwt.verify(token, secret);
      next();
    }catch(e){
      return res.status(401).json({ error: "Invalid token" });
    }
  };
}

export function adminOnly(req, res, next){
  if(req.user?.role !== "admin") return res.status(403).json({ error: "Admin only" });
  next();
}
