export const COLORS = ["RED", "YELLOW", "GREEN", "BLUE"];
export const COLOR_INDEX = { RED: 0, YELLOW: 1, GREEN: 2, BLUE: 3 };

export const SAFE_CELLS = new Set([0, 8, 13, 21, 26, 34, 39, 47]);

const ENTRY = { RED: 0, YELLOW: 13, GREEN: 26, BLUE: 39 };
const HOME_LEN = 6;

function newTokens(){ return [-1,-1,-1,-1]; }

export function createGame(roomId){
  return {
    roomId,
    mode: "PVP",
    players: { RED: null, YELLOW: null, GREEN: null, BLUE: null }, // socket.id or "BOT"
    turn: "RED",
    dice: null,
    mustMove: false,
    winner: null,
    tokens: { RED: newTokens(), YELLOW: newTokens(), GREEN: newTokens(), BLUE: newTokens() },
    last: null
  };
}

export function canJoin(game, color){
  return COLORS.includes(color) && !game.players[color];
}
export function joinGame(game, color, playerId){
  game.players[color]=playerId; return game;
}
export function allPlayersReady(game){
  return COLORS.every(c => !!game.players[c]);
}
export function rollDice(game){
  if(game.winner) return game;
  const d = 1 + Math.floor(Math.random()*6);
  game.dice=d; game.mustMove=true;
  game.last={type:"ROLL", dice:d, by:game.turn};
  return game;
}

function isOnLoop(pos){ return pos>=0 && pos<=51; }
function isHomePos(pos){ return pos>=1000 && pos<=1039; }
function homeBase(color){ return 1000 + COLOR_INDEX[color]*10; }
function isFinished(pos, color){ return pos === homeBase(color) + (HOME_LEN-1); }

function loopDistFromEntry(color, pos){
  const e=ENTRY[color];
  if(!isOnLoop(pos)) return null;
  return (pos - e + 52) % 52;
}
function loopPosFromEntry(color, dist){
  const e=ENTRY[color];
  return (e + dist) % 52;
}
function homeStep(color, pos){
  const hb = homeBase(color);
  return pos - hb;
}

export function listMoves(game, color, dice){
  const moves=[];
  if(game.winner) return moves;
  if(game.turn!==color) return moves;

  const my=game.tokens[color];
  for(let i=0;i<my.length;i++){
    const pos=my[i];

    if(pos===-1){
      if(dice===6) moves.push({tokenIndex:i, to:ENTRY[color], kind:"ENTER"});
      continue;
    }

    if(isFinished(pos,color)) continue;

    if(isOnLoop(pos)){
      const dist=loopDistFromEntry(color,pos);
      const nd=dist + dice;

      if(nd<=51){
        moves.push({tokenIndex:i, to:loopPosFromEntry(color, nd), kind:"MOVE"});
      } else {
        const intoHome = nd - 52;
        if(intoHome <= HOME_LEN-1){
          moves.push({tokenIndex:i, to:homeBase(color)+intoHome, kind:"HOME"});
        }
      }
      continue;
    }

    if(isHomePos(pos)){
      const hs=homeStep(color,pos);
      const nh = hs + dice;
      if(nh <= HOME_LEN-1){
        moves.push({tokenIndex:i, to:homeBase(color)+nh, kind:"HOME"});
      }
    }
  }
  return moves;
}

function captureIfNeeded(game, moverColor, toPos){
  if(!isOnLoop(toPos)) return null;
  if(SAFE_CELLS.has(toPos)) return null;

  for(const enemyColor of COLORS){
    if(enemyColor===moverColor) continue;
    const enemy=game.tokens[enemyColor];
    for(let j=0;j<enemy.length;j++){
      if(enemy[j]===toPos){
        enemy[j]=-1;
        return {color:enemyColor, tokenIndex:j};
      }
    }
  }
  return null;
}

function checkWinner(game){
  for(const c of COLORS){
    if(game.tokens[c].every(p=>isFinished(p,c))){
      game.winner=c;
      game.last={type:"WIN", winner:c};
      return;
    }
  }
}

export function nextTurn(game){
  const idx = COLORS.indexOf(game.turn);
  for(let k=1;k<=4;k++){
    const c = COLORS[(idx+k)%4];
    if(game.players[c]) return c;
  }
  return game.turn;
}

function endTurnMaybe(game, diceRolled){
  if(diceRolled===6){
    game.dice=null; game.mustMove=false;
    return;
  }
  game.turn = nextTurn(game);
  game.dice=null; game.mustMove=false;
}

export function applyMove(game, color, tokenIndex, to){
  if(game.winner) return game;
  if(game.turn!==color) return game;
  if(!game.mustMove || !game.dice) return game;

  const dice=game.dice;
  const legal=listMoves(game,color,dice).find(m=>m.tokenIndex===tokenIndex && m.to===to);
  if(!legal) return game;

  game.tokens[color][tokenIndex]=to;

  const cap=captureIfNeeded(game,color,to);
  game.last={type:"MOVE", by:color, dice, tokenIndex, to, capture:cap};

  checkWinner(game);
  if(!game.winner) endTurnMaybe(game,dice);
  return game;
}
