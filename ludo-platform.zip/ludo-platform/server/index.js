import "dotenv/config";
import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { createServer } from "http";
import { Server } from "socket.io";

import { initDb } from "./db.js";
import { signToken, authRequired, adminOnly } from "./auth.js";
import { COLORS, SAFE_CELLS, createGame, canJoin, joinGame, allPlayersReady, rollDice, applyMove, listMoves, nextTurn } from "./game.js";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || "dev_secret_change_me";
const db = initDb(process.env.DB_PATH || "./data.sqlite");

// Bootstrap admin if missing
(function bootstrapAdmin(){
  const email = process.env.ADMIN_BOOTSTRAP_EMAIL;
  const pass = process.env.ADMIN_BOOTSTRAP_PASSWORD;
  if(!email || !pass) return;
  const existing = db.prepare("SELECT id FROM users WHERE email=?").get(String(email).toLowerCase());
  if(existing) return;
  const hash = bcrypt.hashSync(pass, 10);
  db.prepare("INSERT INTO users (email,password_hash,display_name,role,balance) VALUES (?,?,?,?,0)")
    .run(String(email).toLowerCase(), hash, "Admin", "admin");
  console.log("✅ Admin bootstrapped:", email);
})();

app.get("/health", (_,res)=>res.json({ok:true}));

// AUTH
app.post("/api/auth/register", (req,res)=>{
  const { email, password, displayName } = req.body || {};
  if(!email || !password) return res.status(400).json({error:"email/password required"});
  const name = (displayName && String(displayName).trim()) || String(email).split("@")[0];
  const hash = bcrypt.hashSync(String(password), 10);
  try{
    const r = db.prepare("INSERT INTO users (email,password_hash,display_name,role,balance) VALUES (?,?,?,?,0)")
      .run(String(email).toLowerCase(), hash, name, "user");
    const user = db.prepare("SELECT id,email,display_name,role,balance FROM users WHERE id=?").get(r.lastInsertRowid);
    const token = signToken(user, JWT_SECRET);
    res.json({token, user});
  }catch(e){
    res.status(400).json({error:"email already exists"});
  }
});

app.post("/api/auth/login", (req,res)=>{
  const { email, password } = req.body || {};
  if(!email || !password) return res.status(400).json({error:"email/password required"});
  const user = db.prepare("SELECT id,email,display_name,role,balance,password_hash FROM users WHERE email=?")
    .get(String(email).toLowerCase());
  if(!user) return res.status(401).json({error:"invalid credentials"});
  if(!bcrypt.compareSync(String(password), user.password_hash)) return res.status(401).json({error:"invalid credentials"});
  const safeUser = { id:user.id, email:user.email, display_name:user.display_name, role:user.role, balance:user.balance };
  const token = signToken(safeUser, JWT_SECRET);
  res.json({token, user:safeUser});
});

app.get("/api/me", authRequired(JWT_SECRET), (req,res)=>{
  const user = db.prepare("SELECT id,email,display_name,role,balance,created_at FROM users WHERE id=?").get(req.user.uid);
  res.json({user});
});

// Wallet
app.get("/api/wallet/ledger", authRequired(JWT_SECRET), (req,res)=>{
  const rows = db.prepare("SELECT id,delta,reason,ref,created_at FROM balance_ledger WHERE user_id=? ORDER BY id DESC LIMIT 50")
    .all(req.user.uid);
  res.json({rows});
});

app.get("/api/deposit-methods", authRequired(JWT_SECRET), (req,res)=>{
  const rows = db.prepare("SELECT id,name,details,is_active FROM deposit_methods WHERE is_active=1 ORDER BY id DESC").all();
  res.json({rows});
});

// Deposit: credits coins instantly (demo; no real gateway)
app.post("/api/deposit", authRequired(JWT_SECRET), (req,res)=>{
  const { amount, methodId, note } = req.body || {};
  const amt = Number(amount);
  if(!Number.isFinite(amt) || amt<=0) return res.status(400).json({error:"amount must be > 0"});
  const tx = db.transaction(()=>{
    db.prepare("INSERT INTO deposits (user_id, method_id, amount, note) VALUES (?,?,?,?)")
      .run(req.user.uid, methodId || null, Math.floor(amt), note || null);
    db.prepare("UPDATE users SET balance = balance + ? WHERE id=?").run(Math.floor(amt), req.user.uid);
    db.prepare("INSERT INTO balance_ledger (user_id, delta, reason, ref) VALUES (?,?,?,?)")
      .run(req.user.uid, Math.floor(amt), "DEPOSIT_CREDIT", methodId ? `method:${methodId}` : null);
  });
  tx();
  const user = db.prepare("SELECT id,email,display_name,role,balance FROM users WHERE id=?").get(req.user.uid);
  res.json({ok:true, user});
});

// Admin
app.get("/api/admin/users", authRequired(JWT_SECRET), adminOnly, (req,res)=>{
  const q = String(req.query.q || "").trim().toLowerCase();
  const rows = q
    ? db.prepare("SELECT id,email,display_name,role,balance,created_at FROM users WHERE lower(email) LIKE ? OR lower(display_name) LIKE ? ORDER BY id DESC LIMIT 100")
        .all(`%${q}%`, `%${q}%`)
    : db.prepare("SELECT id,email,display_name,role,balance,created_at FROM users ORDER BY id DESC LIMIT 100").all();
  res.json({rows});
});

app.post("/api/admin/users/adjust-balance", authRequired(JWT_SECRET), adminOnly, (req,res)=>{
  const { userId, delta, reason } = req.body || {};
  const uid = Number(userId);
  const d = Number(delta);
  if(!Number.isFinite(uid) || !Number.isFinite(d)) return res.status(400).json({error:"invalid input"});
  const why = String(reason || "ADMIN_ADJUST").slice(0,80);
  const tx = db.transaction(()=>{
    db.prepare("UPDATE users SET balance = balance + ? WHERE id=?").run(Math.floor(d), uid);
    db.prepare("INSERT INTO balance_ledger (user_id, delta, reason, ref) VALUES (?,?,?,?)")
      .run(uid, Math.floor(d), why, `admin:${req.user.uid}`);
  });
  tx();
  const user = db.prepare("SELECT id,email,display_name,role,balance FROM users WHERE id=?").get(uid);
  res.json({ok:true, user});
});

app.get("/api/admin/deposit-methods", authRequired(JWT_SECRET), adminOnly, (req,res)=>{
  const rows = db.prepare("SELECT id,name,details,is_active,created_at FROM deposit_methods ORDER BY id DESC").all();
  res.json({rows});
});
app.post("/api/admin/deposit-methods", authRequired(JWT_SECRET), adminOnly, (req,res)=>{
  const { name, details, isActive } = req.body || {};
  if(!name || !details) return res.status(400).json({error:"name/details required"});
  const r = db.prepare("INSERT INTO deposit_methods (name, details, is_active) VALUES (?,?,?)")
    .run(String(name).slice(0,80), String(details).slice(0,500), isActive===0?0:1);
  const row = db.prepare("SELECT id,name,details,is_active FROM deposit_methods WHERE id=?").get(r.lastInsertRowid);
  res.json({ok:true, row});
});
app.patch("/api/admin/deposit-methods/:id", authRequired(JWT_SECRET), adminOnly, (req,res)=>{
  const id = Number(req.params.id);
  const exists = db.prepare("SELECT id,name,details,is_active FROM deposit_methods WHERE id=?").get(id);
  if(!exists) return res.status(404).json({error:"not found"});
  const { name, details, isActive } = req.body || {};
  db.prepare("UPDATE deposit_methods SET name=?, details=?, is_active=? WHERE id=?")
    .run(name!=null?String(name).slice(0,80):exists.name,
         details!=null?String(details).slice(0,500):exists.details,
         isActive!=null?(isActive?1:0):exists.is_active,
         id);
  const row = db.prepare("SELECT id,name,details,is_active FROM deposit_methods WHERE id=?").get(id);
  res.json({ok:true, row});
});

// Socket.io game
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: true } });

const games = new Map();
function getOrCreate(roomId){ if(!games.has(roomId)) games.set(roomId, createGame(roomId)); return games.get(roomId); }
function broadcast(roomId){ io.to(roomId).emit("game:state", games.get(roomId)); }
function isBot(game, color){ return game.players[color] === "BOT"; }

function botPickMove(game, color){
  const dice=game.dice;
  const moves=listMoves(game,color,dice);
  if(!moves.length) return null;
  const enemyPos = new Set();
  for(const ec of COLORS){
    if(ec===color) continue;
    for(const p of game.tokens[ec]){
      if(p>=0 && p<=51) enemyPos.add(p);
    }
  }
  const cap = moves.find(m=>enemyPos.has(m.to) && !SAFE_CELLS.has(m.to));
  if(cap) return cap;
  const enter = moves.find(m=>m.kind==="ENTER");
  if(enter) return enter;
  return moves[0];
}

function runBotIfNeeded(roomId){
  const game=games.get(roomId);
  if(!game || game.winner) return;
  if(!allPlayersReady(game)) return;
  const color=game.turn;
  if(!isBot(game,color)) return;

  const stepRoll=()=>{
    if(game.winner || game.turn!==color || game.mustMove) return;
    rollDice(game);
    broadcast(roomId);
    setTimeout(stepMove, 420);
  };
  const stepMove=()=>{
    if(game.winner || game.turn!==color || !game.mustMove || !game.dice) return;
    const pick=botPickMove(game,color);
    if(!pick){
      game.turn = nextTurn(game);
      game.dice=null; game.mustMove=false;
      broadcast(roomId);
      setTimeout(()=>runBotIfNeeded(roomId), 220);
      return;
    }
    applyMove(game,color,pick.tokenIndex,pick.to);
    broadcast(roomId);
    setTimeout(()=>runBotIfNeeded(roomId), 520);
  };
  setTimeout(stepRoll, 320);
}

io.on("connection", (socket)=>{
  socket.on("room:join", ({roomId, color, mode, token})=>{
    const game=getOrCreate(roomId);
    // optional auth
    if(token){
      try{ jwt.verify(token, JWT_SECRET); } catch(e){ socket.emit("room:error",{message:"Invalid login token"}); return; }
    }
    if(mode) game.mode = (mode==="BOT" ? "BOT" : "PVP");

    if(!canJoin(game,color)){
      socket.emit("room:error",{message:"Slot not available"}); return;
    }
    joinGame(game,color,socket.id);
    socket.join(roomId);

    if(game.mode==="BOT"){
      for(const c of COLORS){ if(!game.players[c]) game.players[c]="BOT"; }
    }

    broadcast(roomId);
    setTimeout(()=>runBotIfNeeded(roomId), 200);
  });

  socket.on("game:roll", ({roomId, color})=>{
    const game=getOrCreate(roomId);
    if(game.players[color]!==socket.id) return;
    if(!allPlayersReady(game) || game.turn!==color || game.mustMove) return;
    rollDice(game); broadcast(roomId);
    setTimeout(()=>runBotIfNeeded(roomId), 200);
  });

  socket.on("game:move", ({roomId, color, tokenIndex, to})=>{
    const game=getOrCreate(roomId);
    if(game.players[color]!==socket.id) return;
    applyMove(game,color,tokenIndex,to); broadcast(roomId);
    setTimeout(()=>runBotIfNeeded(roomId), 200);
  });

  socket.on("game:listMoves", ({roomId, color})=>{
    const game=getOrCreate(roomId);
    if(game.players[color]!==socket.id || game.turn!==color) return;
    if(!game.mustMove || !game.dice){ socket.emit("game:moves",{moves:[]}); return; }
    socket.emit("game:moves",{moves:listMoves(game,color,game.dice)});
  });

  socket.on("disconnect", ()=>{
    for(const g of games.values()){
      for(const c of COLORS){ if(g.players[c]===socket.id) g.players[c]=null; }
    }
  });
});

httpServer.listen(PORT, ()=>console.log("Server listening on", PORT));
